//<!-- jQuery call to the accordion() method. -->
//<!-- From the accordin widget activity -->
//<!-- displays images from each accordin tab on prevention methods -->
$(document).ready(function () {
    $("#tabs").accordion({
        collapsible: true,
        active: false,
        heightStyle: "content",
        animate: true
    });
});